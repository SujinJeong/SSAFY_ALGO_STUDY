package week9;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

public class back_10800 {
	static int [][] man;
	static int [][] dp;
	static boolean[] visited;
	static ArrayList<Integer> [] list;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		
		int N = Integer.parseInt(br.readLine());
		
		man = new int [N][2];
		list = new ArrayList[N+1];
		for(int i=1; i<=N; i++) {
			list[i] = new ArrayList<>();
		}
		int max_r=0;
		for(int i=0; i<N; i++) {
			st = new StringTokenizer(br.readLine());
			int c = Integer.parseInt(st.nextToken());
			int s = Integer.parseInt(st.nextToken());
			man[i][0] = c;
			man[i][1] = s;
			list[c].add(s);
			max_r = Math.max(c, max_r);
		}
		int max=0;
		for(int i=1; i<=N; i++) {
			if(list[i].size()!=0) {
				Collections.sort(list[i]);
				max = Math.max(max, list[i].size());
			}
		}
		
		dp = new int [max_r+1][max];
		for(int i=1; i<=max_r; i++) {
			for(int j=0; j<list[i].size(); j++) {
				if(j==0) dp[i][j] = list[i].get(0);
				else dp[i][j] = dp[i][j-1] + list[i].get(j);
			}
		}
		visited = new boolean[N+1];
		for(int i=0; i<N; i++) {
			int sum=0;
			Arrays.fill(visited, false);
			for(int j=0; j<N; j++) {
				if(visited[man[j][0]] || i==j || man[i][0]==man[j][0]) continue;
				visited[man[j][0]] = true;
				int r = binary(j,man[i][1]);
				if(r == -1) continue;
				sum+=dp[man[j][0]][r];
			}
			sb.append(sum+"\n");
		}
		System.out.println(sb);
	}
	private static int binary(int i, int c_s) {
		int c = man[i][0];
		int s = man[i][1];
		int low=0, high = list[c].size();
		int mid=0;
		
		while(low<=high) {
			mid = (low+high) / 2;
			int m = list[c].get(mid);
			if(s>m) {
				low = mid+1;
			}
			else if(s<m) {
				high = mid-1;
			}
			else break; // mid랑 같을 때
		}
		
		if (mid==0 && c_s<list[c].get(mid)) return -1;
		else if(c_s>list[c].get(mid)) return mid;
		else if(c_s==list[c].get(mid)) return mid-1;
		else return -1;
	}
}
