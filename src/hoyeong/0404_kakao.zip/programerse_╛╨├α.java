package week9;

import java.util.ArrayList;

public class programerse_압축 {

	public static void main(String[] args) {
		String msg = "KAKAO";
		int a = 'A';
		
		System.out.println(solution(msg));
	}
	static public int[] solution(String msg) {
        int[] answer = {}; // 결과값
        ArrayList<String> list = new ArrayList<>(); // 추가된 값
        
        
        return answer;
    }

}
